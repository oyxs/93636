<?php

return array (
	'default' => array (
		'hostname' => 'localhost',
		'database' => '93636_sql',
		'username' => 'root',
		'password' => 'miguan',
		'tablepre' => '93636_sso_',
		'charset' => 'utf8',
		'type' => 'mysql',
		'debug' => true,
		'pconnect' => 0,
		'autoconnect' => 0
		)
);

?>