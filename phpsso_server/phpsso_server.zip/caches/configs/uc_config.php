<?php 
define('UC_CONNECT', 'mysql');
define('UC_API', 'http://localhost/comsenz/uc');
define('UC_IP', '');
define('UC_DBHOST', 'localhost');
define('UC_DBUSER', 'root');
define('UC_DBPW', 'root');
define('UC_DBNAME', 'ucenter');
define('UC_DBTABLEPRE', 'uc_');
define('UC_DBCHARSET', 'gbk');
define('UC_APPID', '8');
define('UC_KEY', 'arqFDAQRFWQE2346fweqre');
define('UCUSE', '0');
