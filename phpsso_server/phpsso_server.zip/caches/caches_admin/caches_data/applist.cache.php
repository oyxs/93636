<?php
return array (
  1 => 
  array (
    'appid' => '1',
    'type' => 'phpcms_v9',
    'name' => 'phpcms v9',
    'url' => 'http://localhost/',
    'authkey' => 'k2aNzzEI5BpEgvVRgon2b06cnt5za6h7',
    'ip' => '',
    'apifilename' => 'api.php?op=phpsso',
    'charset' => 'utf-8',
    'synlogin' => '1',
  ),
);
?>